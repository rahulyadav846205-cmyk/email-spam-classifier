# Email Spam Classifier

## Task 2 - CODTECH Internship

This project uses Machine Learning and Natural Language Processing (NLP) to classify email messages as **Spam** or **Ham (Not Spam)**.

### Technologies
- Python
- Pandas
- Scikit-learn
- TF-IDF Vectorization
- Multinomial Naive Bayes
- Joblib

### Project Structure
```text
email-spam-classifier/
├── spam.csv
├── spam_classifier.py
├── predict.py
├── requirements.txt
└── README.md
```

### How to Run

1. Install Python 3.9+.
2. Install dependencies:
```bash
pip install -r requirements.txt
```
3. Train the model:
```bash
python spam_classifier.py
```
4. Run interactive prediction:
```bash
python predict.py
```

### How It Works

1. Loads the labelled email dataset.
2. Cleans and normalizes email text.
3. Converts text into numerical features using TF-IDF.
4. Trains a Multinomial Naive Bayes classifier.
5. Evaluates the model using accuracy, classification report and confusion matrix.
6. Saves the trained model as `spam_classifier.pkl`.
7. Uses the saved model for new email predictions.

### Example

Input:
`Congratulations! You won a free cash prize. Click now!`

Output:
`Prediction: SPAM`

Input:
`Can we meet after class to discuss the project?`

Output:
`Prediction: HAM`

## Note
The included CSV is a compact demonstration dataset for the internship task. For production use, the model should be trained on a much larger, diverse and properly validated email dataset.
