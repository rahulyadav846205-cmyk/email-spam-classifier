import re
import joblib

MODEL_FILE = "spam_classifier.pkl"

def clean_text(text):
    text = str(text).lower()
    text = re.sub(r"http\S+|www\S+", " URL ", text)
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    return re.sub(r"\s+", " ", text).strip()

model = joblib.load(MODEL_FILE)

print("Email Spam Classifier")
print("Type an email message (or type 'exit' to quit).")

while True:
    message = input("\nEmail: ")
    if message.lower() == "exit":
        break
    result = model.predict([clean_text(message)])[0]
    print("Prediction:", result.upper())
