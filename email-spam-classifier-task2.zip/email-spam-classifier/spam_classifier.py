import re
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

DATA_FILE = "spam.csv"
MODEL_FILE = "spam_classifier.pkl"

def clean_text(text):
    text = str(text).lower()
    text = re.sub(r"http\S+|www\S+", " URL ", text)
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    return re.sub(r"\s+", " ", text).strip()

def main():
    data = pd.read_csv(DATA_FILE)
    data = data.dropna(subset=["label", "message"])
    data["message"] = data["message"].apply(clean_text)

    X_train, X_test, y_train, y_test = train_test_split(
        data["message"], data["label"],
        test_size=0.25, random_state=42, stratify=data["label"]
    )

    model = Pipeline([
        ("tfidf", TfidfVectorizer(
            ngram_range=(1, 2),
            min_df=1,
            sublinear_tf=True
        )),
        ("classifier", MultinomialNB())
    ])

    model.fit(X_train, y_train)
    predictions = model.predict(X_test)

    print("=" * 55)
    print("EMAIL SPAM CLASSIFIER")
    print("=" * 55)
    print(f"Test Accuracy: {accuracy_score(y_test, predictions):.2%}")
    print("\nClassification Report:")
    print(classification_report(y_test, predictions, zero_division=0))
    print("Confusion Matrix:")
    print(confusion_matrix(y_test, predictions))

    joblib.dump(model, MODEL_FILE)
    print(f"\nModel saved as: {MODEL_FILE}")

    examples = [
        "Congratulations! You won a free cash prize. Click now!",
        "Can we meet after class to discuss the project?"
    ]
    print("\nSample Predictions:")
    for email in examples:
        print(f"{email} -> {model.predict([clean_text(email)])[0].upper()}")

if __name__ == "__main__":
    main()
